/***********************************************************************
 * Source File:
 *    Bullet : The dot on the screen which goes on until it hits something
 *             or reaches out of bounds
 * Author:
 *    David Pruitt
 *    Felipe Centeno
 * Summary:
 *    Everything we need to know about the bullets on the screen and how they
 *    act, such as out of bounds, and wrap, including hiting a object.
 ************************************************************************/

#include "bullet.h"
#include "point.h"
#include "uiDraw.h"


#include <cassert>
#include <GL/gl.h>        // Main OpenGL library
#include <GL/glut.h>      // Second OpenGL library

/******************************************
 * Bullet : This is our constructor for the bullets
 *****************************************/
Bullet::Bullet()
{
   range = 0;
   setSize(-2);
   dead = false;
   setType('b');
}

/******************************************
 * Bullet : This is our constructor for the bullets
 *****************************************/
Bullet::Bullet(Vector vec, float angle)
{
   setSize(-2);
   v.setAngle(angle);
   v += vec;
   dead = false;
   range = 0;
}

/*******************************************
 * Bullet : kill() : this is going to kill the bullet
 * upon the two conditions of hitting an object, or
 * going out of bounds.
 *******************************************
void Bullet::kill()
{
   dead = true;
   return;
}

/*******************************************
 * Bullet : draw() : This is going to graw a dot
 * for us on the screen to represent our bullet(s).
 *******************************************/
void Bullet::draw()
{
   // Yellow Bullets
   glColor3f(1.0 /* red % */, 1.0 /* green % */, 0.0 /* blue % */);
   drawDot(v.getPoint());
   return;
}


/*******************************************
 * Bullet : Advance() : this is going to make the
 * bullet move across the screen depending on the
 * variable of speed.
 *******************************************/
void Bullet :: increment()
{
   range++;
   if (range > 30)
      Inertia::kill();
   v.advance();
   return;
}

/*******************************************
 * Bullet : Advance() : this is going to make the
 * bullet move across the screen depending on the
 * variable of speed.
 *******************************************/
void Bullet::hit(Inertia *element, Asteroid & asteroids)
{
   return;
}

/******************************************
 * Bullet insertion
 *       Display coordinates for the bullet
 *****************************************/
std::ostream & operator << (std::ostream & out, Bullet rhs)
{
   out << "(" << rhs.getVector().getDx() << ", "
       << rhs.getVector().getDy() << ")";
   return out;
}
