/***********************************************************************
 * Source File:
 *    Ship : This is the Triangle on the screen that will look like it shoots
 * Author:
 *    David Pruitt
 *    Felipe Centeno
 * Summary:
 *    Everything we need to know about the object Ship, including the
 *    angle position and location.
 ************************************************************************/
#include "ship.h"  // This includes the header file of the rifle
#include "point.h"
#include "uiDraw.h"
#include "bullet.h"

#include <cassert>
#include <list>

#define SPEED_SHIP .2
#define ROTATE_SPD 10
/******************************************
 * Ship(): this is our constuctor, setting
 * angle to 135 degrees to begin the game.
******************************************/
Ship :: Ship()
{
   // Set the starting Angle position to 135
   angle = 0;
   setSize(8);
   v.setPoint().setWrap(true);
   setType('s');
}

/********************************************
 * Ship : move
 * Rotates the rifle using the rotate function
 * in the uiDraw.cpp file up and down are for
 * rifle rotations moving in a up and down
 * like way
 *******************************************/
void Ship :: rotate(int right, int left)
{
   // When the input is for the Left Direction
   if (left)
   {
      angle -= ROTATE_SPD;
   }

   // When the input is for the Right Direction
   if (right)
   {
      angle += ROTATE_SPD;
   }

   angle %= 360;
   assert(angle < 360 && angle >= -360);
   v.setAngle(angle);  // This is the set angle for the ship
   
}

/********************************************
 * Ship : draw
 * draws the rifle and at the 135 starting angle
 *******************************************/
void Ship :: draw()
{
   drawShip(v.getPoint(),angle);
}
/********************************************
 * Ship : Move
 * Move the ship with the input of up.
 *******************************************/
void Ship :: impulse(float up, float down)
{
   float temp;
   float directionX;
   float directionY;
  
   //its easier to work only with possitives
   if (angle < 0)
      temp = angle + 360;
   else
      temp = angle;
   // When the input is for the Up Direction
   assert(temp < 360 && temp >= 0);
   //we only want values between 0 - 360        
      
   if (up)
   {
      directionX = findDistance(270,temp); //defined in vector
      directionY = findDistance(360,(temp));
      assert(directionX + directionY == 90);
      //this will allow us to go in any direction in a cardinal square
      if (temp < 90 || temp > 270)
         directionX *= -1;
      // if (increaseY < 0 || increaseY > 180)
      if (temp < 180)
         directionY *= -1;

    
      v.setAngle(angle);  // This is the set angle for the ship
      //v.adjust((SPEED_SHIP/90.0) * directionX, (SPEED_SHIP/90.0) * directionY);
      v.setDx((SPEED_SHIP/90.0) * directionX);
              // The Horizontal coordinate
      v.setDy((SPEED_SHIP/90.0) * directionY); // The Vertical   coordinate
      // v.advance();        // Allows the ship to move forward
   }

// When the input is for the Down Direction
   // if (down)
   // {
   //    v.setAngle(angle);
   //    v.setDx(-1.2);
   //    v.setDy(-1.2);
   // }
}

/*******************************************
 * Ship : Fire() : This is going to pass the 
 * bullet though the ships pointer towards the
 * direction it was fired
 *******************************************/
void Ship::fire( std::list<Inertia*> & objects)
{
   objects.push_back( new Bullet(v,angle));
   
}
/********************************************
 * Ship : interact
 * This will allow the user to interact with
 * the games ship
 *******************************************/
void Ship :: interact(const Interface * pUI,std::list<Inertia*> & objects)
{
   rotate(pUI->isLeft(), pUI->isRight());
   // orientation -= (pUI,left * 10) + (pUI.rigt * 10)
   
   impulse(pUI->isUp(), pUI->isDown());
   
   if(pUI->isSpace())
   {
      fire(objects);
   }
}

/******************************************
 * Rock : Hit : This will tell us whether or
 * not the rock hit a bullet or ship.
 *****************************************/
void Ship :: hit (Inertia * element, Asteroid & asteroids)
{
   kill();
}

