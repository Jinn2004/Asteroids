/***********************************************************************
 * Source File:
 *    Vector : The representation of the speed of an object on the screen
 * Author:
 *   Felipe Centeno
 * Summary:
 *    Everything we need to know about a location on the screen, including
 *    the location and the bounds.
 ************************************************************************/

#include "vector.h"
#include <cassert>
#include <math.h>

#define BULLET_SPD 5.0
/******************************************
 * VECTOR : CONSTRUCTOR WITH X,Y
 * Initialize the point to the passed position
 *****************************************/
Vector::Vector(float dx, float dy) : dx(0.0), dy(0.0)
{
   setDx(dx);
   setDy(dy);
}

/*******************************************
 * This function will just return the closest distance
 * between two points in a circle
 *******************************************/
float findDistance(float a, float b)
{
   int one = a - b;
   if (a > 270 && b < 90)
      one = b;
  
   //compare them both
   if (one < 0)
      one *= -1;
 
   //distance from the other end
   int two = a - 180 - b; 
   if (two < 0)
      two *= -1;
 
   if(one > two)
      one = two;
   return one;
}
/********************************************
 * VECTOR : Assignment
 *******************************************/
const Vector & Vector :: operator = (const Vector & rhs)
{
   dx = (rhs.dx);
   dy = (rhs.dy);
   point = rhs.getPoint();
   angle = rhs.getAngle();
   return *this;
}

/********************************************
 * VECTOR : This is the speed of the ship plus
 * a little  extra speed of the bullet
 *******************************************/
const Vector & Vector :: operator += (const Vector & rhs)
{
   float temp = temp = rhs.getAngle();
   if (rhs.getAngle() < 0)
      temp = rhs.getAngle() + 360;
   assert(temp >= 0 && temp <= 360);

   float tempX = findDistance(270, temp);//(temp % 90);
   float tempY = findDistance(360, temp);//(temp % 90);
   
   assert(tempX >= 0 && tempX <= 90);
   assert(tempY >= 0 && tempY <= 90);
   assert(tempX + tempY == 90);
   if (temp < 90 || temp >= 270)
      tempX *= -1;
   if (temp < 180)
      tempY *= -1;
   assert(tempX >= -90 && tempX <= 90);
   assert(tempY >= -90 && tempY <= 90);
      
   dx = (rhs.getDx() + (BULLET_SPD/90.0) * tempX);
   dy = (rhs.getDy() + (BULLET_SPD/90.0) * tempY);
   point = rhs.getPoint();
   angle = rhs.getAngle();
   advance();
   advance();
   //advance(); 
   return *this;
}
/******************************************
 * Skeet :: hit : this is going to test to
 * see if the bullet and bird colide.
 *****************************************/
float returnGreater(float a, float b, float c, float d)
{
   // if negative make positive
   if (a < 0)
      a = -a;
   else if (b < 0)
      b = -b;
   else if (c < 0)
      c = -c;
   else if (d < 0)
      d = -d;

   if (a == 0)
      a = 1.0;
   else if (b == 0)
      b = 1.0;
   else if (c == 0)
      c = 1.0;
   else if (d == 0)
      d = 1.0;

   if (a > b && a > c && a > d)
      return a;
   else if ( b > c && b > d)
      return b;
   else if ( c > d)
      return c;
   else
      return d;   
}

/******************************************
 * VECTOR insertion
 *       Display coordinates on the screen
 *****************************************/
std::ostream & operator << (std::ostream & out, const Vector & vec)
{
   out << "(" << vec.getDx() << ", " << vec.getDy() << ")";
   return out;
}

/*******************************************
 * VECTOR extraction
 *       Prompt for coordinates
 ******************************************/
std::istream & operator >> (std::istream & in, Vector & vec)
{
   float dx;
   float dy;
   in >> dx >> dy;

   vec.setDx(dx);
   vec.setDy(dy);

   return in;
}


/******************************************
 * Asteroid :: hit : this is going to test to
 * see if the bullet and bird colide.
 *****************************************/
float Vector :: operator - (const Vector & rhs) const
{
   float slice = 1.0 / returnGreater(dx, dy, rhs.dx, rhs.dy);
      
   float minDist = 1000000000;
   //std::cout << "slice: " << slice << std::endl;
   // assert((slice >= 0) && (slice <= 1));
   
   for (float percent = 0; percent <= 1; percent += slice)
   {
      float distanceSquared =
         // diffenence actual pos of rock and end of rock
         // act bullet - end bullet
         // squaring it
         
         ( ((point.getX() + dx * percent)
           - (rhs.getPoint().getX() + rhs.dx * percent))
          *  
          ((point.getX() + dx * percent) 
           - (rhs.getPoint().getX() + rhs.dx * percent))
          
          //     the same up there but in Y
          +
          ((point.getY() + dy * percent)
           - (rhs.getPoint().getY() + rhs.dy * percent))
           *
           ((point.getY() + dy * percent)
           - (rhs.getPoint().getY() + rhs.dy * percent)));
        
      assert(distanceSquared >= 0);
          
      if (minDist > distanceSquared)
      {
         minDist = distanceSquared;
      }  
      //    minDist = fminf(distanceSquared, minDist);
   }
   //std::cout << sqrt(minDist) << std::endl;
   return sqrt(minDist);
}

