/***********************************************************************
 * Header File:
 *    Ship : The object of a Ship on the screen 
 * Author:
 *    Felipe Centeno
 *    David Pruitt
 * Summary:
 *    Everything we need to know the object Ship, including
 *    the location, bounds, and angle position.
 ************************************************************************/

#ifndef SHIP_H
#define SHIP_H

#include "uiInteract.h"
#include "spinner.h"
#include "inertia.h"
//#include "asteroid.h"
#include <list>
#include <iostream> // needed for insertion and extraction operator
                    // Using intergers for angles between 180-90 degrees
class Asteroid;
/*********************************************
 * Ship
 * A triangle object in space rotating at the center of the triangle
 * from a 0 to 360 degree position.
 *********************************************/
class Ship : public Spinner
{   
   // Step 2 : Declare the functions that will be called (methods)
  public:

   // Step 3 : Declare your constuctor
   Ship();

   void interact(const Interface * pUI, std::list<Inertia*> & objects);
   void rotate(int left, int right);
   void draw();
   void hit(Inertia *element, Asteroid & asteroids);
   void fire(std::list<Inertia*> & objects );
   void impulse(float up, float down);

   // Declare your Acessors
};

#endif // SHIP_H
