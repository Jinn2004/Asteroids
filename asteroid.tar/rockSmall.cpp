/***********************************************************************
 * Source File:
 *    rockSmall : This is the triangle representing a small rock.
 * Author:
 *    David Pruitt
 * Summary:
 *    Everything we need to know about a location on the screen, including
 *    the location and the bounds.
 ************************************************************************/

#include "uiDraw.h"
#include "cstdlib"
#include <cassert>
#include "rockSmall.h"
#include "asteroid.h"

#define SPEED 5.5
#define XSTART -155
#define YSTART -100
/******************************************
 * POINT : CONSTRUCTOR WITH X,Y
 * Initialize the point to the passed position
 *****************************************/
RockSmall :: RockSmall()
{   // We want to wrap around the edge
   v.getPoint().setWrap(true);
   v.setPoint().setWrap(true);
   // A random speed is given to the rock in a random direction
   v.setDx(rand() % 5 - SPEED);
   v.setDy(rand() % 5 - SPEED);
   // Its a size 8.
   setSize(8);
   setType('r');
   resurrect();
}

/******************************************
 * POINT : CONSTRUCTOR WITH X,Y
 * Initialize the point to the passed position
 *****************************************/
RockSmall :: RockSmall(Vector vect)
{
   v.setPoint() = vect.getPoint();
   v.setDx(rand() % 5 - SPEED);
   v.setDy(rand() % 5 - SPEED);
   resurrect();
   setSize(8);
   v.setPoint().setWrap(true);
   setType('r');
   assert(dead == false);
}
/******************************************
 * Rock Draw : This will draw a bowtie like shape
 * it recieves a new velocity upon being made.
 *****************************************/
void RockSmall :: draw()
{
   // Get the center point of the polygon, rotate its angle
   drawSmall(v.getPoint(), angle++);
   return;
}

/******************************************
 * Rock increment
 *****************************************/
void RockSmall :: increment()
{
   v.advance();
   return;
}
