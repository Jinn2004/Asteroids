/***********************************************************************
 * Header File:
 *   Vector : The representation of the speed of an object on the screen
 * Author:
 *   Felipe Centeno
 * Summary:
 *    Everything we need to know about a location on the screen, including
 *    the location and the bounds.
 ************************************************************************/

#ifndef VECTOR_H
#define VECTOR_H

#include "point.h"
#include <iostream> // needed for insertion and extraction operator

struct Speed
{
   float x;
   float y;
};
/*********************************************
 * VECTOR
 * A single position.  
 *********************************************/
class Vector
{
  public:
   // constructors
  Vector()            : dx(0.0), dy(0.0) {}
   Vector(float dx, float dy);
   Vector(const Vector & vector) { *this = vector; }

   void advance() {point.addX(dx); point.addY(dy);}
   void adjust(){speed.x = dx; speed.x = dy;}
   //Vector opertator += (float a){dx += a;  dy += a; return *this;}
   //void opertator ++(int postfix) {point.addX(dx); point.addY(dy);}
  
   // setters
   float setDx(float a){dx += a;}
   float setDy(float b){dy += b;}
   float setAngle(float ang){angle = ang;}
   Point & setPoint() {return point;}
   // getters
   float getAngle() const {return angle;}
   float getDx()    const {return dx;}
   float getDy()    const {return dy;}
   Point getPoint() const {return point;}

   //operators
   float operator - (const Vector & rhs) const;
   const Vector & operator = (const Vector & rhs);
   const Vector & operator += (const Vector & rhs);

  private:
   float dx;           // horizontal position
   float dy;           // vertical position
   Speed speed;
   Point point;
   float angle;         // we could call it orientation
};

// stream I/O useful for debugging
//float operator - (const Vector & lhs, const Vector & rhs);
float findDistance(float a, float b);
std::ostream & operator << (std::ostream & out, const Vector & vec);
std::istream & operator >> (std::istream & in,        Vector & vec);

#endif // VECTOR_H
