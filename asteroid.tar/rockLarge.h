/***********************************************************************
 * Header File:
 *    Point : The representation of a position on the screen
 * Author:
 *    Felipe Centeno
 *    David Pruitt
 * Summary:
 *    This is my Rock class
 ************************************************************************/

#ifndef ROCKLARGE_H
#define ROCKLARGE_H
#include "spinner.h"
#include "bullet.h"
#include <iostream> // needed for insertion and extraction operator
#include "point.h"
#include "rock.h"
//#include "asteroid.h"
class Asteroid;
/*********************************************
 * RockSmall
 * A single small rock.  
 *********************************************/
class RockLarge : public Rock
{
  public:   
   //  Step 1:  Declare the Constuctor
   RockLarge();
      
   // Step 2: Declare the Public Methods
   void draw();

   // Step 3: Declare the Acessors

   // Step 4: Declare the Mutators.

 
   void increment();
   bool isDead()      {return dead;}
   void kill()        {dead = true;}
   void hit(Inertia *element,  Asteroid & asteroids);

};

#endif // RockLarge_H
