/***********************************************************************
 * Source File:
 *    Bird : This is the bird that will fly across the screen
 * Author:
 *    David Pruitt
 * Summary:
 *    Everything we need to know about a location on the screen, including
 *    the location and the bounds.
 ************************************************************************/

#include "uiDraw.h"
#include "cstdlib"
#include <cassert>
#include "rock.h"
#include "rockMedium.h"
#include "asteroid.h"
#define SPEED 4.5
#define XSTART -155
#define YSTART -100
class Asteroid;
/******************************************
 * RockMedium : CONSTRUCTOR WITH X,Y
 * Initialize the point to the passed position
 *****************************************/
RockMedium :: RockMedium()
{
   // vKick.setDx(random(-1.5, 1.5));
   // vKick.setDy(random(-1.5, 1.5));
   // v += vKick;
   v.setPoint().setWrap(true);
   v.setDx(rand() % 5 - SPEED);
   v.setDy(rand() % 5 - SPEED);
   setSize(15);
   setType('r');
   resurrect();
}

/******************************************
 * RockMedium : CONSTRUCTOR WITH vector
 * Initialize the point to the passed position
 *****************************************/
RockMedium :: RockMedium(Vector vect)
{
   resurrect();
   v.setPoint() = vect.getPoint();
   v.getPoint().setWrap(true);
   setSize(15);
   setType('r');
   v.setDx(rand() % 5 - SPEED);
   v.setDy(rand() % 5 - SPEED);
   assert(dead == false);
   //sert(v.setPoint(). == vect.getPoint());
}

/******************************************
 * RockMedium Draw() This is going to draw out
 * the medium size rock which will look like
 * a tie fighter.
 *****************************************/
void RockMedium :: draw()
{
   // Get the center of the polygon, rotate its angle.
   drawMedium(v.getPoint(), angle++);
   return;
}

/******************************************
 * RockMedium increment : This is going to cause the
 * medium size rock to move.
 *****************************************/
void RockMedium :: increment()
{
   v.advance();
   return;
}

/******************************************
 * RockMedium hit(): this is going to tell us
 * whether or not the rock hit or not.
 *****************************************/
void RockMedium :: hit(Inertia *element, Asteroid & asteroids)
{
   kill();
   element->kill();
   asteroids.addItem(new RockSmall(v));
   asteroids.addItem(new RockSmall(v));
}
