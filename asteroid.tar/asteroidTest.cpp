#include "uiInteract.h"
#include "uiDraw.h"
#include "asteroid.h"
#include "bullet.h"
#include "score.h"
#include "ship.h"
#include "rock.h"
using namespace std; // do we really want this?


/*************************************
 * All the interesting work happens here, when
 * I get called back from OpenGL to draw a frame.
 * When I am finished drawing, then the graphics
 * engine will wait until the proper amount of
 * time has passed and put the drawing on the screen.
 **************************************/
void callBack(const Interface *pUI, void * p)
{   
   Asteroid *pgame = (Asteroid*)p;
   pgame->Interact(pUI);
   pgame->move();
   pgame->draw();

   return;
}
/*********************************
 * Main is pretty sparse.  Just initialize
 * my ball type and call the display engine.
 * That is all!
 *********************************/
int main(int argc, char ** argv)
{ 
   Interface ui(argc, argv, "Test");    // initialize OpenGL
   Asteroid game;                           // initialize the game state
   ui.run(callBack, &game);             // set everything into action

   return 0;
}
