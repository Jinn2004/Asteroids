/***********************************************************************
 * Source File:
 *    Rock : This is the class rock its the parent of at least three offspring
 *    Small, medium, and Large.
 * Author:
 *    David Pruitt
 *    Felipe Centeno
 * Summary:
 *    Everything we need to know about the Rock class, how it interacts with
 *    the user and how it calls which rock is needed.
 ************************************************************************/

#include "uiDraw.h"
#include "cstdlib"
#include <list>
#include <cassert>
#include "rock.h"

#define SPEED 4
#define XSTART -155
#define YSTART -100
/******************************************
 * Rock Constuctor
 * Initialize the rock that will be used in the game
 *****************************************/
Rock::Rock()
{
   v.setPoint().setWrap(true);
   v.setPoint().setX(rand() % -200 + 70);
   v.setPoint().setY(rand() % -200 + 70);
}

/******************************************
 * Rock : Interact() : This is for the interactions
 * the player will have the the rocks
 *****************************************/
void Rock ::interact (const Interface * pUI, std::list<Inertia*> & objects)
{
   return;
}

/******************************************
 * Rock : rotate : This is going to rotate
 * the Asteroids for us, using spinner.h
 *****************************************/
void Rock :: rotate(int left, int right)
{
}
