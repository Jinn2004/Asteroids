/***********************************************************************
 * Header File:
 *    Rock : The representation of a Rock on the screen it is the offspring
 *    of a spinner since in space asteroids will rotate in a certain direction
 *    and in 2D space they spin in a certain direction.
 * Author:
 *    Felipe Centeno
 *    David Pruitt
 * Summary:
 *    This is my Rock class
 ************************************************************************/

#ifndef ROCK_H
#define ROCK_H
#include "spinner.h"
#include "bullet.h"
#include <iostream> // needed for insertion and extraction operator
#include "point.h"
#include <list>
#include "inertia.h"
class Asteroid;    // prototype to make the game work
/*********************************************
 * Rock
 * A single position.  
 *********************************************/
class Rock : public Spinner
{
   // Step 1: Declare the Public Methods
  public:
   void interact(const Interface * pUI, std::list<Inertia*> & objects);   
   void rotate(int left, int right);

    // Step 3: Declare the Constuctor
   Rock();

};

#endif // Rock_H
