/***********************************************************************
 * Header File:
 *    Point : The representation of a position on the screen
 * Author:
 *    Felipe Centeno
 *    David Pruitt
 * Summary:
 *    This is my Rock class
 ************************************************************************/

#ifndef ROCKSMALL_H
#define ROCKSMALL_H
#include "spinner.h"
#include <iostream> // needed for insertion and extraction operator
#include "point.h"
#include "rock.h"
#include "vector.h"
class Asteroid;
/*********************************************
 * RockSmall
 * A single small rock.  
 *********************************************/
class RockSmall : public Rock
{
  public:   
     
   // Declare the Constuctor
   RockSmall();
   RockSmall(Vector v);
   
   // Declare the Public Methods
   void draw();
   void increment();
   bool isDead()                   {return dead;}
   void hit(Inertia *element, Asteroid & asteroids){element->kill(); dead = true;}
  private:
};

#endif // RockSmall_H
