/***********************************************************************
 * Source File:
 *    Inertia : This is everything we would to implement in the game using
 *    the physics of an inertia.
 * Author:
 *    David Pruitt
 *    Felipe Centeno
 * Summary:
 *    Inertia is something stays in motion until it is acted upon another
 *    variable so in this case this will help us understand how the physics
 *    of the game is going to work.
 ************************************************************************/

#include "inertia.h"  // This includes the header file of the rifle
#include "point.h"
#include "uiDraw.h"

/********************************************
 * inertia : Kill() this is going to stop the
 * inertia of the game, most likly upon the
 * removing of an object in the game.
 *******************************************/
void Inertia :: kill()
{
      
}
