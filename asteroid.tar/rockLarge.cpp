/***********************************************************************
 * Source File:
 *    RockLarge : This is the large size Rock which will be flying and spinning
 *    across the screen
 * Author:
 *    David Pruitt
 * Summary:
 *    Everything we would want to know about the LargeRock class which will
 *   include the way its drawn, how it interacts with bullets and ships, and
 *   how it moves.
 ************************************************************************/

#include "uiDraw.h"
#include "cstdlib"
#include <cassert>
#include "rockLarge.h"
#include "asteroid.h"
#define SPEED 3.5
#define XSTART -155
#define YSTART -100
/******************************************
 * RockLarge() : This is our LargeRock Constructor.
 * it will allow the large Rock to wrap around corners
 * it will be 30 pixels big on the screen
 * it will be random at its speed increment
 *****************************************/
RockLarge :: RockLarge()
{
   // We want to wrap around the edge
   v.getPoint().setWrap(true);
   // The rock is 30 pixels wide
   setSize(18);
     // A random generator to the speed and direction of the rock
   v.setDx(rand() % 5 - SPEED);
   v.setDy(rand() % 5 - SPEED);
   setType('r');
}


/******************************************
 * Rock Draw(): This will draw the rock for us.
 *****************************************/
void RockLarge :: draw()
{
   // Draw the Center of the Polygon, then Rotate its angle
   drawLarge(v.getPoint(), angle++);
   return;
}

/******************************************
 * Rock increment : This is going to cause
 * the rockLarge to move forward.
 *****************************************/
void RockLarge :: increment()
{
   v.advance();
   return;
}

/******************************************
 * Rock hit : This will make new rocks
 * depending on if the rock colides with a
 * object such as ship or bullet.
 *****************************************/
void RockLarge :: hit(Inertia *element, Asteroid & asteroids)
{
   kill();
   element->kill();
   asteroids.addItem(new RockSmall(v));
   asteroids.addItem(new RockMedium(v));
   asteroids.addItem(new RockMedium(v));
}

