/***********************************************************************
 * Header File:
 *    Rifle : The object of a rifle on the screen 
 * Author:
 *    David Pruitt
 * Summary:
 *    Everything we need to know the object rifle, including
 *    the location, bounds, and angle position.
 ************************************************************************/

#ifndef SPINNER_H
#define SPINNER_H

//#include "asteroid.h"
#include "inertia.h"
#include <iostream> // needed for insertion and extraction operator
                    // Using intergers for angles between 180-90 degrees

/*********************************************
 * Spinner
 * A box object in space rotating at the center of the box from a 90 to 180
 * degree position.
 *********************************************/
class Spinner : public Inertia
{   
   // Step 1: Declare your public Variables
  public:
   int angle;
   // Step 2 : Declare your constuctor
   //remember to make this virtual fuction with the time     
   virtual void rotate(int left, int right) = 0;
   //bool hit(Inertia *element, Asteroid & asteroid){v - element.v;}
   
   // Step 3: Declare your Acessors
   int getAngle() {return angle;}
   void setAngle(int a) {angle = a;}
};

#endif // SPINNER_H
