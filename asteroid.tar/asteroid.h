/***********************************************************************
 * Header File:
 *    Asteroid : this is the header file for the class Asteroid.
 * Author:
 *    Felipe Centeno
 *    David Pruitt
 * Summary:
 *    Everything we need to know about the game asteroids, how it calls
 *    certain functions such as draw, hit and interact in the game play.
 ************************************************************************/

#ifndef ASTEROID_H
#define ASTEROID_H

#include <iostream> // needed for insertion and extraction operator
#include <cassert>
#include <math.h>
#include <valarray> // this is for the Slice dealio
#include <list>

#include "uiInteract.h"
#include "uiDraw.h"
#include "bullet.h"
#include "score.h"
#include "ship.h"
#include "rock.h"
#include "rockLarge.h"
#include "rockMedium.h"
#include "rockSmall.h"
#include "inertia.h"
/*********************************************
 * Asteroid
 * A game class
 *********************************************/
class Asteroid
{
public:
   // Step 1 : Declare our Constuctor
   Asteroid();

   // Step 2 : Declare our Public Methods
   void draw();
   void Interact(const Interface * pUI);
   void move();
   void advance();
   void addItem(Inertia *element)
   {objects.insert(objects.end(),element);}
   float hit();

   // Step 3: Declare our private Variables and Methods
private:
   void miss();
   std::list <Inertia*>  objects;
};

#endif // ASTEROID_H
