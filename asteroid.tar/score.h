/***********************************************************************
 * Header File:
 *    Score : The object of a score board on the screen 
 * Author:
 *    David Pruitt
 * Summary:
 *    Everything we need to know about the score board, it will
 *    use the draw to show an object for digits to display, it will
 *    get used by skeet and increment up depending on the events such
 *    as the hit bird, and out of bounds bird.
 ************************************************************************/

#ifndef SCORE_H
#define SCORE_H

#include <iostream> // needed for insertion and extraction operator

/*********************************************
 * Score
 * This is going to keep the score for the player and the game
 * It will draw it on both the left hand side and right hand side
 *********************************************/
class Score
{
  private:
   int score;
   
  public:

   // Functions
   Score();
   void draw(int score);

   // increment the score
   void incrementScore();
   
   // Getters
   int getScore();

};

#endif // SCORE_H
