/***********************************************************************
 * Header File:
 *    Rifle : The object of a rifle on the screen 
 * Author:
 *    David Pruitt
 * Summary:
 *    Everything we need to know the object rifle, including
 *    the location, bounds, and angle position.
 ************************************************************************/


#include "spinner.h"
#include <iostream> // needed for insertion and extraction operator
                    // Using intergers for angles between 180-90 degrees

/*********************************************
 * Spinner
 * A box object in space rotating at the center of the box from a 90 to 180
 * degree position.
 *********************************************/

