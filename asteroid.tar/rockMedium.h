/***********************************************************************
 * Header File:
 *    Point : The representation of a position on the screen
 * Author:
 *    Felipe Centeno
 *    David Pruitt
 * Summary:
 *    This is my Rock class
 ************************************************************************/

#ifndef ROCKMEDIUM_H
#define ROCKMEDIUM_H
#include "spinner.h"
#include "bullet.h"
#include <iostream> // needed for insertion and extraction operator
#include "point.h"
#include "rock.h"
class Asteroid;
/*********************************************
 * RockSmall
 * A single small rock.  
 *********************************************/
class RockMedium : public Rock
{
  public:   
   // Declare the Constuctor
   RockMedium();
   RockMedium(Vector v);
   
   // Declare the Public Methods
   void draw();
   void increment();
   void hit(Inertia *element, Asteroid & asteroids);
   bool isDead()            {return dead;}
  private:
};

#endif // RockMedium_H
