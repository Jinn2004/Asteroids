/***********************************************************************
 * Header File:
 *    Inertia : This is the header file for inertia which will make the
 *    game run more smoothly with continuos movement with the principle
 *    of inertia which is to be in motion and stay in motion until a new
 *    new force adds or takes away from it.
 * Author:
 *    Felipe Centeno
 * Summary:
 *    Everything we need to know about Inertia whats in motion stays in motion
 *    until acted upon by another object.
 ************************************************************************/

#ifndef INERTIA_H
#define INERTIA_H
#include "vector.h"
#include "uiInteract.h"
#include <list>

class Asteroid;
/*********************************************
 * Inertia Class
 *********************************************/
class Inertia
{
   // Step 1: Declare the Private Variables
  private:
   char type;
   int size;
   // Step 2: Declare the Public Methods.
  public:
  Inertia() :dead(false){}
   bool dead;
  
   virtual void draw() = 0;
   virtual void hit(Inertia *element, Asteroid & asteroids) = 0;
   virtual void interact(const Interface * pUI,
                         std::list<Inertia*> & objects) = 0;
   virtual void increment() {v.advance();}
//   virtual void increment() = 0;

   Vector v;

   // Step 4: Declare the Accesors
   int getSize()         {return size;}
   char getType()         {return type;}
   Vector getVector()    {return v;}

   // Step 5: Declare the Mutators
   char setType(char a){type = a;}
   int setSize(int a) {size = a;}
   void kill() { dead = true;}
   void resurrect() {dead = false;}
   bool isDead()    {return dead;}
        
};
#endif // INERTIA_H
 
