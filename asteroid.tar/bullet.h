/***********************************************************************
 * Header File:
 *    Bullet : header file for our bullet class.
 * Author:
 *    David Pruitt
 *    Felipe Centeno
 * Summary:
 *    Everything we need to know about our bullet class including how it
 *    works within the game.
 ************************************************************************/

#ifndef BULLET_H
#define BULLET_H

#include <iostream> // needed for insertion and extraction operator
#include <list>

#include "point.h"
#include "uiInteract.h"
#include "inertia.h"
/*********************************************
 * Bullet class
 *********************************************/
class Bullet : public Inertia
{
   // Step 1: Declare the Private Variables
  private:
   int range;

   // Step 2: Declare the Public Methods
  public:
   //using inertia::kill();
   bool fire(int angle);
   void draw();
   void hit(Inertia *element, Asteroid & asteroids);
   void advance();
   void interact(const Interface * pUI, std::list<Inertia*> & objects){}
   virtual void increment();
   // Step 3: We need a Point point (to get the point)
   Point point;
   
   // Step 4: Declare the Mutators
   bool isDead()       {return dead;}
   void kill();
  
   // Step 6: Declare the Non-Default Constructor
   Bullet();
   Bullet(Vector vec, float angle);

   // Step 7: Decalre the Destructor
   ~Bullet() {}
   
};

std::ostream & operator << (std::ostream & out, Bullet rhs);
std::istream & operator >> (std::istream & in, Bullet rhs);
#endif // BULLET_H
 
