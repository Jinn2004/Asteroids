/***********************************************************************
 * Source File:
 *    Asteroid : This is the file that will make the entire game work
 * Author:
 *       David Pruitt
 *       Felipe Centeno
 * Summary:
 *    Everything we need to know about the game asteroids and what gets
 *    called when it needs to be called.
 ************************************************************************/
#include "asteroid.h"           // We need this for the Rocks
#include "ship.h"               // We need this for the ship
#include "inertia.h"
#include "rockLarge.h"
#include "vector.h"
#define SCREEN_SIZE 250.0
#define xMAX SCREEN_SIZE
#define xMIN -SCREEN_SIZE
#define yMAX SCREEN_SIZE
#define yMIN -SCREEN_SIZE
// only to make it compile, this is from pong
float Point::xMin = -SCREEN_SIZE;
float Point::xMax =  SCREEN_SIZE;
float Point::yMin = -SCREEN_SIZE;
float Point::yMax =  SCREEN_SIZE;
using namespace std;

/******************************************
 * SKEET : CONSTRUCTOR WITH X,Y
 * Initialize the point to the passed position
 *****************************************/
Asteroid::Asteroid()
{
   objects.insert(objects.end(), new Ship);
   objects.insert(objects.end(), new RockLarge);
   objects.insert(objects.end(), new RockLarge);
   objects.insert(objects.end(), new RockLarge);
   objects.insert(objects.end(), new RockLarge);
   objects.insert(objects.end(), new RockLarge);
}

/******************************************
 * Asteroid :: draw() this is going to draw the
 * Asteroid game for ship, Asteroid, score, and bullet
 *****************************************/
void Asteroid::draw()
{  
   for(std::list<Inertia*>::iterator it = objects.begin();
       it != objects.end(); ++it)
   {
      (*it)->draw();
   }
   return;
}

/******************************************
 * Asteroid : Interact : This is going to put
 * the objects we interact with on the screen
 * depending on the object it may take commands
 * from user input such as thrust.
 *****************************************/
void Asteroid::Interact(const Interface * pUI)
{
   for(std::list<Inertia*>::iterator it = objects.begin();
       it != objects.end(); ++it)
   {
      for(std::list<Inertia*>::iterator iter = objects.begin();
          iter != objects.end(); ++iter)
      {  
         if (it != iter &&
             ((*it)->getSize() + (*iter)->getSize()) >
             ((*it)->v - (*iter)->v)
             && (*it)->getType() != (*iter)->getType())
         {
            std::cout <<((*it)->getSize() + (*iter)->getSize())
                      <<" it 1: " << (*it)->getSize() << "it2: "<< (*iter)->getSize()
                      << "vector: " <<  ((*it)->v - (*iter)->v)
                      << std::endl;
            
            (*it)->hit(*iter,*this);
         }
      }
      (*it)->interact(pUI, objects);
   }

   return;
}
/******************************************
 * Asteroid :: Move : This is going to take the
 * user input such as up, down, left, right
 * and make it rotate the ship. This will
 * also take the Spacebar input to shoot
 *****************************************/
void Asteroid::move()
{
   for(std::list<Inertia*>::iterator it = objects.begin();
       it != objects.end(); ++it)
   {
      (*it)->increment();
      if ((*it)->isDead())
      {
         it = objects.erase(it);
      }
   }
   return;
}

/******************************************
 * Asteroid :: advance : This is the method
 * that will make all of the objects in space
 * move in the game.
 *****************************************/
void Asteroid::advance()
{
   for (int i = 0 /*inertia object*/; ;i++)
   {
      //     inertia[i].advance();
      // if (inertia[i].isDead())
      //  inertia[i].erase();
   }
}

