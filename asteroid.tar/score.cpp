/***********************************************************************
 * Source File:
 *    Score : this will be two score board that will count up over time.
 * Author:
 *    David Pruitt
 * Summary:
 *    This will be the score information, counting up, where its located,
 *    what is to show and how it all works
 ************************************************************************/

#include "score.h"  // This includes the header file of the rifle
#include "uiDraw.h" // This is so we can draw the numbers
#include "point.h"  // This is for the point values
#include <GL/gl.h>        // Main OpenGL library Colors!
#include <GL/glut.h>      // Second OpenGL library
/******************************************
 * Score(): this is our constuctor for Score
******************************************/
Score :: Score()
{
   score = 0;
}

/********************************************
 * Score : draw
 * draws the scoreboard for the Player and Game
 *******************************************/
void Score :: draw(int score)
{
   Point topLeft;
   
   // Color the ScoreBoard!
   glColor3f(1.0 /* red % */, 1.0 /* green % */, 1.0 /* blue % */);

   // set X for Player 
   topLeft.setX(-240);
   // Set y for Player
   topLeft.setY(240);
   // point topRight, digit for Player
   drawNumber(topLeft, score);
   
}

/********************************************
 * Score : setScore
 * Sets the players score.
 *******************************************/
void Score::incrementScore()
{
   // Increment the number up by condition
   score++;
}

/********************************************
 * Score : getScorePlayer
 * Gets the players score.
 *******************************************/
int Score :: getScore()
{
   // Get the score for the player
   return score;
   
}

